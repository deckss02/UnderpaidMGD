﻿namespace Febucci.HierarchyData.Examples
{
     
    [UnityEngine.AddComponentMenu("Febucci/HierarchyIcons/ClassC")]
    class ClassC : UnityEngine.MonoBehaviour
    {
        
    }
   
}