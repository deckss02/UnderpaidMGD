﻿namespace Febucci.HierarchyData.Examples
{
     
    [UnityEngine.AddComponentMenu("")]
    abstract class BaseClassB : UnityEngine.MonoBehaviour
    {
        
    }
   
}