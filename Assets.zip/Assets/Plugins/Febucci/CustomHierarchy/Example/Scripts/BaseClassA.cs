﻿namespace Febucci.HierarchyData.Examples
{
     [UnityEngine.AddComponentMenu("")]
    abstract class BaseClassA : UnityEngine.MonoBehaviour
    {
        
    }
   
}