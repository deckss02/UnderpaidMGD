﻿namespace Febucci.HierarchyData.Examples
{
    [UnityEngine.AddComponentMenu("Febucci/HierarchyIcons/ClassA")]
    class ClassA : BaseClassA
    {
        
    }
   
}