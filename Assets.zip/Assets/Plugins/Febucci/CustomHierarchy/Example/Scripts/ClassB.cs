﻿namespace Febucci.HierarchyData.Examples
{
     
    [UnityEngine.AddComponentMenu("Febucci/HierarchyIcons/ClassB")]
    class ClassB : BaseClassB
    {
        
    }
   
}