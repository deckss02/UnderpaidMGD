using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerSave : MonoBehaviour
{
    public TMP_InputField inputFieldName;
    public TMP_InputField inputFieldScore;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
